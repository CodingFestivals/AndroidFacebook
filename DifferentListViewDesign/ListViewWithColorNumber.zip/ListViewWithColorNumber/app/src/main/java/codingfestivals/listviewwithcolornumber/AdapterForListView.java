package codingfestivals.listviewwithcolornumber;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
class ViewHolder{
    TextView textView_question_number,textView_question;
    public  ViewHolder(View row){
        textView_question_number=row.findViewById(R.id.id_tv_questions_number);
        textView_question=row.findViewById(R.id.id_tv_questions_text);
    }
}
public class AdapterForListView extends BaseAdapter {
    Context context;
    //data(string and color) collect from string filse
    ArrayList<String> questionList;
    ArrayList<Integer> colorList;
    public AdapterForListView(Context context) {
        this.context = context;
        questionList=new ArrayList<>();
        colorList=new ArrayList<>();
        String[] qustion_name=context.getResources().getStringArray(R.array.all_question);
        String[] colors_name=context.getResources().getStringArray(R.array.all_colors);
        //question store in question list
        for (int i=0;i<qustion_name.length;i++) {
            questionList.add(qustion_name[i]);
        }
        //color store in color list
        for (int i=0;i<colors_name.length;i++){
            colorList.add(Color.parseColor(colors_name[i]));
        }
    }

    @Override
    public int getCount() {
        //how many data
        return questionList.size();
    }

    @Override
    public Object getItem(int position) {
        //specific position item return
        return questionList.get(position);
    }

    @Override
    public long getItemId(int position) {
        //retrun position of item
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row=convertView;
        //here we create ViewHolder class for not finding views(textView,...) for every item in list
        //LayoutInflater is costly or time consuming function that's why we trying to not call LayoutInflater function by using holder class
        ViewHolder holder;
        if(row==null){
            LayoutInflater inflater= (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row=inflater.inflate(R.layout.single_row,parent,false);
            holder=new ViewHolder(row);
            row.setTag(holder);
        }
        //get ViewHolder for View object
        holder= (ViewHolder) row.getTag();
        //set question  in textView
        holder.textView_question.setText(questionList.get(position));
        //set question number in textview
        holder.textView_question_number.setText(Integer.toString(position+1));
        //set background color in textview of question_number
        holder.textView_question_number.setBackgroundColor(colorList.get((position)%colorList.size()));
        return row;
    }
}
