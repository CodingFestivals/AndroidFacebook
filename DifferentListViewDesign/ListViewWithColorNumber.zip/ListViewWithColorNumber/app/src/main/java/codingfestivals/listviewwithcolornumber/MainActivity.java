package codingfestivals.listviewwithcolornumber;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Set Action Bar Title And Set Image
        getSupportActionBar().setTitle("All Question");
        Drawable drawable=getResources().getDrawable(R.drawable.screen_blank);
        getSupportActionBar().setBackgroundDrawable(drawable);
        //find listview
        listView=findViewById(R.id.id_lv_question);
        //Adapter set for Question
        listView.setAdapter(new AdapterForListView(this));
    }
}